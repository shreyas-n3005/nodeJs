const csvFilePath = 'customer-data.csv'
const fs = require('fs')
const csv = require('csvtojson')
let arr = []

var c = csv();
c.fromFile(csvFilePath)

.on('json',function(jsonObj){
arr.push(jsonObj)
})
.on('done',(error)=>{
fs.writeFile('myOutputFile.json', JSON.stringify(arr,null,2), (error)=>{
process.exit(0)
})
})