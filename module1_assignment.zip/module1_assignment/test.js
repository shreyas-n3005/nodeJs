var message="Hello world"
console.log(message)